﻿using System;


namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
           Person person = new Person();

            //person.Name = "bobi";
            //person.Age = 37;


            //Console.WriteLine($"Name: {person.Name}");
            //Console.WriteLine($"Age: {person.Age}");

        }
    }
}